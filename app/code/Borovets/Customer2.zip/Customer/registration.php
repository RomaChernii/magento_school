<?php
/**
 * Borovets Customer registration
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Borovets_Customer',
    __DIR__
);
